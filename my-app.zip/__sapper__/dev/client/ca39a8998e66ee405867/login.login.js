(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login"],{

/***/ "./src/routes/login.svelte":
/*!*********************************!*\
  !*** ./src/routes/login.svelte ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/svelte-loader/index.js):\nError: ParseError: </div> attempted to close an element that was not open (62:0)\n60:     </div>\r\n61:   </div>\r\n62: </div>\n    ^\n    at C:\\Users\\ogtay\\Desktop\\sapper\\my-app\\node_modules\\svelte-loader\\index.js:181:12");

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYTM5YTg5OThlNjZlZTQwNTg2Ny9sb2dpbi5sb2dpbi5qcyIsInNvdXJjZVJvb3QiOiIifQ==