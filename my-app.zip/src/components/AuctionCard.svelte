<script>

</script>

<style>

</style>

<div class="p-2 mb-2 w-full sm:w-1/2 lg:w-1/3 rounded ">
  <div class="relative pb-56 rounded-lg overflow-hidden shadow-lg">
    <img
      class="absolute w-full h-full object-cover"
      src="https://picsum.photos/500/500"
      alt="Sunset in the mountains" />
  </div>
  <div class=" relative bg-white shadow-lg mx-4 -mt-20 rounded-md">

    <div class="px-6 py-4 ">
      <div
        class="font-semibold text-gray-600 mb-1 flex items-center uppercase
        justify-between ">
        <span>Start &bull; $150</span>
        <span>Time &bull; 14 hours</span>
      </div>
      <div class="font-bold text-xl mb-2 flex items-center">
        <span
          class=" rounded-full bg-teal-200 text-teal-900 uppercase px-2 py-1
          text-xs font-bold mr-1 tracking-widest">
          New
        </span>
        <span>The Coldest Sunset</span>
      </div>
      <p class="text-gray-700 text-base clear-both">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus
      </p>
    </div>
    <div class="bg-gray-400 rounded-full px-6 w-full h-px h-1" />
    <div class="px-6 py-1 mt-1 mb-2">
      <span
        class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm
        font-semibold text-gray-700 mr-2"
        style="font-size: 12px">
        #photography
      </span>
    </div>
  </div>
</div>
